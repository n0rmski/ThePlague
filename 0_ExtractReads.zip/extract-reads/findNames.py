#!/usr/bin/env python


__author__ = 'jashortt'

import argparse
import os
import sys
import gzip

def getNames (file):
	names = {}
	with open (file, 'r') as infp:
		for line in infp:
			name = line.strip()
			if name not in names:
				names[name] = 1
			else:
				print 'Read id %s is already stored in memory' % (name)
	return names

def main(args):
	names = getNames (args.read_names)
	print 'Loaded dictionary with %s read ids to search' % (len(names.keys()))
	with gzip.open(args.fastq, 'r') as infp, open(args.out, 'w') as outfp:
		print 'Opened file %s to search for reads in dictionary' % (args.fastq)
		found = 0
		seqs_read = 0
		for line in infp:
			seqs_read += 1
			read_name, idx = line.strip().split()
			id = read_name.replace("@","")
			seq = infp.readline()
			info = infp.readline()
			qual = infp.readline()
			if id in names:
				outfp.write('%s%s%s%s' % (line, seq, info, qual))
				found += 1
	print 'Found %s names in %s reads in the fastq' % (str(found), str(seqs_read))
				

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    
    parser.add_argument('--fastq', help='fastq file containing reads of interest', required=True)
    parser.add_argument('--read_names', help='file giving read names of interest',  required=True)
    parser.add_argument('--out', help='name of output',  required=True)

    args = parser.parse_args()
    main(args)
    sys.exit()